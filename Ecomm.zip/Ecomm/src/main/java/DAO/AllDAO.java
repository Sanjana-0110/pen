package DAO;

import java.util.List;

import model.Product;

public interface AllDAO {
	List<Product> getAllProducts() throws ClassNotFoundException;

}
