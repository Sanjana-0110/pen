package DAL;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import DAO.AllDAO;
import dbcon.DBConnectionManager;
import model.Product;

public class AllProductsDAL implements AllDAO {

	@Override
	public List<Product> getAllProducts() {
		List<Product> products = new ArrayList<>();
		String s = "SELECT * FROM products2003";
		try {
			Connection connection = DBConnectionManager.getConnection();

			PreparedStatement preparedStatement = connection.prepareStatement(s);
			ResultSet rs = preparedStatement.executeQuery();

			while (rs.next()) {
				Product product = new Product();
				product.setPid(rs.getInt("pid"));
				product.setPcid(rs.getInt("pcid"));
				product.setPname(rs.getString("pname"));
				product.setPrice(rs.getDouble("price"));
				product.setHsncode(rs.getString("hsncode"));
				product.setImage(rs.getString("image"));
				products.add(product);
			}
		} catch (SQLException e) {
			e.printStackTrace();
		}
		return products;
	}

	// Implement other methods of the AllDAO interface as needed
}
