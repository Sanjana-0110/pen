package demo;

import java.io.IOException;
import java.io.InputStream;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.List;
import java.util.Properties;

public class OrderDAO {

	private static Properties properties = new Properties();

	static {
		try {
			// Load the properties file
			InputStream inputStream = OrderDAO.class.getClassLoader().getResourceAsStream("db.properties");
			properties.load(inputStream);

			// Load the database driver
			Class.forName(properties.getProperty("db.driver"));
		} catch (IOException | ClassNotFoundException e) {
			e.printStackTrace();
		}
	}

	private Connection getConnection() throws SQLException {
		// Establish connection using properties
		return DriverManager.getConnection(properties.getProperty("db.url"), properties.getProperty("db.username"),
				properties.getProperty("db.password"));
	}

	public int insertOrder(Order order) {
		String sql = "INSERT INTO orders2003 (oid, oname, ototal, cid) VALUES (?, ?, ?, ?) RETURNING oid;";
		try (Connection conn = getConnection(); PreparedStatement stmt = conn.prepareStatement(sql)) {
			int oid = OIDGenerator.generateOID();
			stmt.setInt(1, oid);
			stmt.setString(2, order.getOname());
			stmt.setDouble(3, order.getOtotal());
			stmt.setInt(4, order.getCid());

			try (ResultSet rs = stmt.executeQuery()) {
				if (rs.next()) {
					return rs.getInt(1);
				}
			}
		} catch (SQLException e) {
			e.printStackTrace();
		}
		return -1; // Error case
	}

	public void insertOrderedProducts(List<OrderedProduct> products) throws SQLException {
		String sql = "INSERT INTO ordered_products2003 (oid, pid, qty, price) VALUES (?, ?, ?, ?);";
		try (Connection conn = getConnection(); PreparedStatement stmt = conn.prepareStatement(sql)) {
			for (OrderedProduct product : products) {
				stmt.setInt(1, product.getOid());
				stmt.setInt(2, product.getPid());
				stmt.setInt(3, product.getQty());
				stmt.setDouble(4, product.getPrice());
				stmt.addBatch();
			}
			stmt.executeBatch();
		}
	}
}
