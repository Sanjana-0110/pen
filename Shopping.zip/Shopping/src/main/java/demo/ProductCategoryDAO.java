
package demo;

import java.io.IOException;
import java.io.InputStream;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;
import java.util.Properties;

public class ProductCategoryDAO {
	private static Properties properties = new Properties();

	static {
		try {
			// Load the properties file
			InputStream inputStream = ProductCategoryDAO.class.getClassLoader().getResourceAsStream("db.properties");
			properties.load(inputStream);

			// Load the database driver
			Class.forName(properties.getProperty("db.driver"));
		} catch (IOException | ClassNotFoundException e) {
			e.printStackTrace();
		}
	}

	public String[] getAllProductCategories() {
		String[] categories = null;
		Connection conn = null;
		PreparedStatement stmt = null;
		ResultSet rs = null;

		try {
			conn = DriverManager.getConnection(properties.getProperty("db.url"), properties.getProperty("db.username"),
					properties.getProperty("db.password"));
			String sql = "SELECT pcname FROM product_category2003";
			stmt = conn.prepareStatement(sql);
			rs = stmt.executeQuery();

			List<String> categoryList = new ArrayList<>();
			while (rs.next()) {
				String pcname = rs.getString("pcname");
				categoryList.add(pcname);
			}

			categories = categoryList.toArray(new String[0]);
		} catch (SQLException e) {
			e.printStackTrace();
		} finally {
			try {
				if (rs != null) {
					rs.close();
				}
				if (stmt != null) {
					stmt.close();
				}
				if (conn != null) {
					conn.close();
				}
			} catch (SQLException e) {
				e.printStackTrace();
			}
		}
		return categories;
	}
}
