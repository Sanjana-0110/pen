package demo;

import java.io.IOException;
import java.util.List;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

public class ProductDefault {
	public void insertpage(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		List<Product> allProducts = null;
		try {
			allProducts = ProductDefaultDAL.getAllProducts();
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} // Assuming you have a method to retrieve all
			// products
		System.out.println("Number of all products retrieved: " + allProducts.size()); // Debugging statement

		// Forward the products list to be displayed
		request.setAttribute("allproducts", allProducts);
		RequestDispatcher rd = request.getRequestDispatcher("index.jsp");
		rd.forward(request, response);

	}
}
