package demo;

import java.io.IOException;
import java.io.InputStream;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.List;
import java.util.Properties;

public class OrderedProductsDAL {
	private static Properties properties = new Properties();

	static {
		try {
			// Load the properties file
			InputStream inputStream = OrderedProductsDAL.class.getClassLoader().getResourceAsStream("db.properties");
			properties.load(inputStream);

			// Load the database driver
			Class.forName(properties.getProperty("db.driver"));
		} catch (IOException | ClassNotFoundException e) {
			e.printStackTrace();
		}
	}

	int insertOrders(double totalPrice, CartList cartList, String username) throws SQLException {
		int oid = 0;
		try {
			int cid = 0;
			ResultSet rs = null;

			// Get customer ID based on username
			try (Connection conn1 = DriverManager.getConnection(properties.getProperty("db.url"),
					properties.getProperty("db.username"), properties.getProperty("db.password"))) {
				String sql1 = "SELECT cid FROM customer2003 WHERE username=?";
				try (PreparedStatement st = conn1.prepareStatement(sql1)) {
					st.setString(1, username);
					rs = st.executeQuery();
					if (rs.next()) {
						cid = rs.getInt("cid");
					}
				}
			}

			// Insert order
			oid = OIDGenerator.generateOID();
			try (Connection conn = DriverManager.getConnection(properties.getProperty("db.url"),
					properties.getProperty("db.username"), properties.getProperty("db.password"))) {
				String sql = "INSERT INTO orders2003 VALUES (?, ?, ?, ?)";
				try (PreparedStatement stmt = conn.prepareStatement(sql)) {
					stmt.setInt(1, oid);
					stmt.setString(2, "order " + oid);
					stmt.setDouble(3, totalPrice);
					stmt.setInt(4, cid);
					stmt.executeUpdate();
				}
			}

			// Insert ordered products
			List<ProductInfo> products = cartList.getAllProducts();
			try (Connection conn = DriverManager.getConnection(properties.getProperty("db.url"),
					properties.getProperty("db.username"), properties.getProperty("db.password"))) {
				String sql2 = "INSERT INTO ordered_products2003 VALUES (?, ?, ?, ?, ?, ?)";
				try (PreparedStatement stmt = conn.prepareStatement(sql2)) {
					for (ProductInfo product : products) {
						stmt.setInt(1, oid);
						stmt.setInt(2, product.getPid());
						stmt.setInt(3, product.getQty());
						stmt.setDouble(4, product.getPrice());
						stmt.setString(5, product.getPname());
						stmt.setDouble(6, product.getGst());
						stmt.addBatch();
					}
					stmt.executeBatch();
				}
			}
		} catch (SQLException e) {
			e.printStackTrace();
		}
		return oid;
	}
}
