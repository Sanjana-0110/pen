package demo;

import java.io.IOException;
import java.io.InputStream;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;
import java.util.Properties;

public class ProductDAO {
	private static Properties properties = new Properties();

	static {
		try {
			// Load the properties file
			InputStream inputStream = ProductDAO.class.getClassLoader().getResourceAsStream("db.properties");
			properties.load(inputStream);

			// Load the database driver
			Class.forName(properties.getProperty("db.driver"));
		} catch (IOException | ClassNotFoundException e) {
			e.printStackTrace();
		}
	}

	public static List<Product> getProductsByCategory(String categoryId) {
		List<Product> products = new ArrayList<>();
		Connection conn = null;
		PreparedStatement stmt = null;
		ResultSet rs = null;

		try {
			conn = DriverManager.getConnection(properties.getProperty("db.url"), properties.getProperty("db.username"),
					properties.getProperty("db.password"));
			String sql = "SELECT p.* FROM products2003 p JOIN product_category2003 pc ON p.pcid = pc.pcid WHERE pc.pcname = ?";
			stmt = conn.prepareStatement(sql);
			stmt.setString(1, categoryId);
			rs = stmt.executeQuery();

			while (rs.next()) {
				Product product = new Product();
				product.setPid(rs.getInt("pid"));
				product.setPcid(rs.getInt("pcid"));
				product.setPname(rs.getString("pname"));
				product.setPrice(rs.getDouble("price"));
				product.setHsncode(rs.getString("hsncode"));
				product.setImage(rs.getString("image"));
				products.add(product);
			}
		} catch (SQLException e) {
			e.printStackTrace();
		} finally {
			try {
				if (rs != null)
					rs.close();
				if (stmt != null)
					stmt.close();
				if (conn != null)
					conn.close();
			} catch (SQLException e) {
				e.printStackTrace();
			}
		}

		return products;
	}

}
