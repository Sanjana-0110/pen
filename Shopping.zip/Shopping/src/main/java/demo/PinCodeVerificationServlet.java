package demo;

import java.io.BufferedReader;
import java.io.IOException;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.google.gson.JsonObject;
import com.google.gson.JsonParser;

@WebServlet("/PinCodeVerificationServlet")
public class PinCodeVerificationServlet extends HttpServlet {
	protected void doPost(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		int dp = 0;
		// Read the JSON data sent from the client
		BufferedReader reader = request.getReader();
		StringBuilder jsonStringBuilder = new StringBuilder();
		String line;
		while ((line = reader.readLine()) != null) {
			jsonStringBuilder.append(line);
		}

		// Convert the JSON data to a JSON object
		JsonObject jsonObject = new JsonParser().parse(jsonStringBuilder.toString()).getAsJsonObject();

		// Get the pincode from the JSON object
		String pincode = jsonObject.get("pincode").getAsString();

		// Now you can use the pincode as needed

		// Example: Set the pincode as a request attribute
		request.setAttribute("pincode", pincode);

		// Example: Send a JSON response back to the client
		JsonObject jsonResponse = new JsonObject();
		jsonResponse.addProperty("message", "Pincode received successfully");
		// Add more properties as needed
		System.out.println(pincode);
		dp = checkDeliverablePincode(pincode);
		response.setContentType("application/json");
		response.setCharacterEncoding("UTF-8");
		response.getWriter().write(jsonResponse.toString());

	}

	public int checkDeliverablePincode(String pincode) {
		try {
			// Load PostgreSQL JDBC driver
			Class.forName("org.postgresql.Driver");
			System.out.println("entered conn ");
			// Connect to the database
			// Connect to the database
			Connection conn = DriverManager.getConnection("jdbc:postgresql://192.168.110.48:5432/plf_training",
					"plf_training_admin", "pff123");

			// Prepare SQL query to check if the pin code exists within the serviceable regions
			String sql = "SELECT srrg_id FROM ServiceableRegions2003 WHERE ? BETWEEN srrg_pinfrom AND srrg_pinto";
			PreparedStatement stmt = conn.prepareStatement(sql);
			stmt.setString(1, pincode);
			System.out.println("pin" + pincode);
			// Execute the query
			ResultSet rs = stmt.executeQuery();

			// Check if the pin code exists within the serviceable regions
			if (rs.next()) {
				int count = rs.getInt(1);
				System.out.println(count);
				return count;
			}

			// Close resources
			rs.close();
			stmt.close();
			conn.close();
		} catch (ClassNotFoundException | SQLException e) {
			e.printStackTrace();
		}
		return 0;
	}
	//
	// private int check(int c) {
	// try {
	// // Load PostgreSQL JDBC driver
	// Class.forName("org.postgresql.Driver");
	// System.out.println("entered conn ");
	// // Connect to the database
	// // Connect to the database
	// Connection conn = DriverManager.getConnection("jdbc:postgresql://192.168.110.48:5432/plf_training",
	// "plf_training_admin", "pff123");
	//
	// // Prepare SQL query to check if the pin code exists within the serviceable regions
	// String sql = "SELECT prct_id FROM ProductCategoryWiseServiceableRegions2003 WHERE srrg_id=?";
	// PreparedStatement stmt = conn.prepareStatement(sql);
	// stmt.setInt(1, c);
	//
	// // Execute the query
	// ResultSet rs = stmt.executeQuery();
	//
	// // Check if the pin code exists within the serviceable regions
	// if (rs.next()) {
	// int pid = rs.getInt(1);
	// System.out.println(pid);
	// System.out.println("pid" + pid);
	// return pid;
	// }
	//
	// // Close resources
	// rs.close();
	// stmt.close();
	// conn.close();
	// } catch (ClassNotFoundException | SQLException e) {
	// e.printStackTrace();
	// }
	// return 0;
	// }
}
