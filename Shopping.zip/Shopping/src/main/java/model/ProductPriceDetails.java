package model;

public class ProductPriceDetails {
	private double pricewithoutgst;
	private double pricewithgst;
	private double shippingchargeshare;
	private double shippingchargewithgst;
	private double shippingamount;
	private double totalcostwithshipping;
	private double totalprice;
	private double gstinprice;
	private double qty;
	public double getQty() {
		return qty;
	}
	public void setQty(double qty) {
		this.qty = qty;
	}
	public double getGstinprice() {
		return gstinprice;
	}
	public void setGstinprice(double gstinprice) {
		this.gstinprice = gstinprice;
	}
	public double getShippingchargewithgst() {
		return shippingchargewithgst;
	}
	public void setShippingchargewithgst(double shippingchargewithgst) {
		this.shippingchargewithgst = shippingchargewithgst;
	}
	
	public double getPricewithoutgst() {
		return pricewithoutgst;
	}
	public void setPricewithoutgst(double pricewithoutgst) {
		this.pricewithoutgst = pricewithoutgst;
	}
	public double getPricewithgst() {
		return pricewithgst;
	}
	public void setPricewithgst(double pricewithgst) {
		this.pricewithgst = pricewithgst;
	}
	public double getShippingchargeshare() {
		return shippingchargeshare;
	}
	public void setShippingchargeshare(double shippingchargeshare) {
		this.shippingchargeshare = shippingchargeshare;
	}
	public double getShippingamount() {
		return shippingamount;
	}
	public void setShippingamount(double shippingamount) {
		this.shippingamount = shippingamount;
	}
	public double getTotalcostwithshipping() {
		return totalcostwithshipping;
	}
	public void setTotalcostwithshipping(double totalcostwithshipping) {
		this.totalcostwithshipping = totalcostwithshipping;
	}
	public double getTotalprice() {
		return totalprice;
	}
	public void setTotalprice(double totalprice) {
		this.totalprice = totalprice;
	}
}
